import tkinter as tk
import globalvars as gv
import GUI
import wave

import wave


def text_to_binary(text):
    binary = ''.join(format(ord(char), '08b') for char in text)
    return binary


def read_message_from_file(file_path):
    with open(file_path, 'r') as file:
        message = file.read()
    return message


def hide_message(audio_file, message_file, output_file):
    # Open the audio file
    audio = wave.open(audio_file, 'rb')

    # Read audio file parameters
    params = audio.getparams()
    num_frames = audio.getnframes()

    # Read message from file
    message = read_message_from_file(message_file)

    # Convert message to binary
    binary_message = text_to_binary(message)

    # Check if message can fit into the audio file
    if len(binary_message) > num_frames:
        print("Error: Message is too large to hide in the audio file.")
        return

    # Read audio data
    audio_data = bytearray(audio.readframes(num_frames))

    # Hide message in LSB of audio data
    for i in range(len(binary_message)):
        if binary_message[i] == '1':
            audio_data[i] |= 1
        else:
            audio_data[i] &= 254

    # Write modified audio data to output file
    with wave.open(output_file, 'wb') as output:
        output.setparams(params)
        output.writeframes(audio_data)

    print("Message hidden successfully.")


# Example usage



gv.init()  # inicializácia globálnych premenných
class SpustitSifro():
    pass

GUI.HlavnyGUI(gv.root)
gv.root.mainloop()

audio_file = gv.input1.get()
message_file = gv.input2.get()
output_file = gv.output.get()+".wav"

hide_message(audio_file, message_file, output_file)



