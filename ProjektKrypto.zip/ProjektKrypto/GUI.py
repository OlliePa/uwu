import tkinter as tk
from tkinter import filedialog
import globalvars as gv


def ZmenaOkna(cislo):
    if cislo == 0:
        gv.root.destroy()
        gv.root = tk.Tk()
        HlavnyGUI(gv.root)
        gv.root.mainloop()
    elif cislo == 1:
        gv.root.destroy()
        gv.root = tk.Tk()
        SifroGUI(gv.root)
        gv.root.mainloop()
    elif cislo == 2:
        gv.root.destroy()
        gv.root = tk.Tk()
        DesifroGUI(gv.root)
        gv.root.mainloop()


class HlavnyGUI:

    def __init__(self, master):
        self.master = master
        self.master.title("Zvukova Steganografia")
        self.nadpis = tk.Label(self.master, text="CHCETE ŠIFROVAŤ ALEBO DEŠIFROVAŤ?", font=("Arial", 15))
        self.nadpis.grid(row=0, column=0, columnspan=3, padx=5, pady=15, sticky="EW")

        self.Tlacitko_Sifrovanie = tk.Button(self.master, text="Šifrovať", command=lambda *args: ZmenaOkna(1),
                                             font=("Arial", 10), bg="#cccccc")
        self.Tlacitko_Sifrovanie.grid(row=1, column=0, padx=20, pady=10, sticky="EW")

        self.Tlacitko_Desifrovanie = tk.Button(self.master, text="Dešifrovať", command=lambda *args: ZmenaOkna(2),
                                             font=("Arial", 10), bg="#cccccc")
        self.Tlacitko_Desifrovanie.grid(row=1, column=2, padx=20, pady=10, sticky="EW")

class DesifroGUI:
    def __init__(self,master):
        self.master = master
        self.master.title("Dešifrovanie")
        self.nadpis = tk.Label(self.master, text="DEŠIFROVANIE SPRÁVY", font=("Arial", 15))
        self.nadpis.grid(row=0, column=0, columnspan=4, padx=5, pady=15, sticky="EW")

        self.input1_label = tk.Label(self.master, text="Vstupny subor Wav:")  # text vlavo
        self.input1_label.grid(row=1, column=0, sticky="e", padx=5, pady=5)  # umiestnenie
        self.input1_entry = tk.Entry(self.master, width=40)  # okienko kde sa vypise cesta
        self.input1_entry.grid(row=1, column=1, padx=5, pady=5,  sticky="w")
        self.input1_button = tk.Button(self.master, text="Browse", command=self.browse_input1,bg="#cccccc")
        self.input1_button.grid(row=1, column=2, pady=5,  sticky="w")

        self.input2_label = tk.Label(self.master, text="Počet Použitých LSB:")
        self.input2_label.grid(row=1, column=3, sticky="e", padx=5, pady=5)
        self.input2_entry = tk.Entry(self.master, width=5)
        self.input2_entry.grid(row=1, column=4, padx=5, pady=5, sticky="w")

        self.output_label = tk.Label(self.master, text="Výstup:")
        self.output_label.grid(row=2, column=0, sticky="e", padx=5, pady=5)
        self.output_entry = tk.Entry(self.master, width=40)
        self.output_entry.grid(row=2, column=1, padx=5, pady=5,sticky ="w")
        self.output_button = tk.Button(self.master, text="Browse", command=self.browse_output, bg="#cccccc")
        self.output_button.grid(row=2, column=2, sticky="w")

        self.end_button = tk.Button(self.master, text ="ok", command=gv.root.destroy,bg="#cccccc")
        self.end_button.grid(row=2, column=4, ipadx=6,padx=5, sticky="w")

    def browse_input1(self):
        filename = filedialog.askopenfilename(filetypes=[("WAV files", "*.wav")])  # otvorenie prehliadaca suborov
        self.input1_entry.delete(0, tk.END)  # vymazanie co je dnu napisane (kvoli vyberu nanovo)
        self.input1_entry.insert(tk.END, filename)  # napisanie cesty dnu do okna
        gv.input1_path.set(filename)  # zadanie cesty do premennej na pouzitie

    def browse_output(self):
        filename = filedialog.askdirectory()
        self.output_entry.delete(0, tk.END)
        self.output_entry.insert(tk.END, filename)
        gv.output_path.set(filename)
class SifroGUI:

    def __init__(self, master):
        self.master = master
        self.master.title("Sifrovanie")
        self.nadpis = tk.Label(self.master, text="ŠIFROVANIE SPRÁVY", font=("Arial", 15))
        self.nadpis.grid(row=0, column=0, columnspan=4, padx=5, pady=15, sticky="EW")

        # ---------v-----okienka pre  prvy vstup-----v---------
        self.input1_label = tk.Label(self.master, text="Vstupny subor Wav:")  # text vlavo
        self.input1_label.grid(row=1, column=0, sticky="e", padx=5, pady=5)  # umiestnenie
        self.input1_entry = tk.Entry(self.master, width=50)  # okienko kde sa vypise cesta
        self.input1_entry.grid(row=1, column=1, columnspan=2, padx=5, pady=5)
        self.input1_button = tk.Button(self.master, text="Browse", command=self.browse_input1, bg ="#cccccc")  # tlacitko na
        # otvorenie prehliadaca
        self.input1_button.grid(row=1, column=3, padx=5, pady=5)



        # ---------v-----okienka pre druhy vstup-----v---------

        self.input2_label = tk.Label(self.master, text="Tajna sprava:")
        self.input2_label.grid(row=2, column=0, sticky="e", padx=5, pady=5)
        self.input2_entry = tk.Entry(self.master, width=50)
        self.input2_entry.grid(row=2, column=1, columnspan=2, padx=5, pady=5)
        self.input2_button = tk.Button(self.master, text="Browse", command=self.browse_input2, bg ="#cccccc")
        self.input2_button.grid(row=2, column=3, padx=5, pady=5)

        # ---------v-----okienka    pre   vystup-----v---------

        self.output_label = tk.Label(self.master, text="Vystup:")
        self.output_label.grid(row=3, column=0, sticky="e", padx=5, pady=5)
        self.output_entry = tk.Entry(self.master, width=50)
        self.output_entry.grid(row=3, column=1, columnspan=2, padx=5, pady=5)
        self.output_button = tk.Button(self.master, text="Browse", command=self.browse_output, bg ="#cccccc")
        self.output_button.grid(row=3, column=3, padx=5, pady=5)

        # ---------v-----okienka pre: info,help,ok(end)-----v---------

        self.info_button = tk.Button(self.master, text="Info", command=self.info, bg ="#cccccc")
        self.info_button.grid(row=4, column=0, padx=5, pady=5, sticky="w")

        self.help_button = tk.Button(self.master, text="Help", command=self.help, bg ="#cccccc")
        self.help_button.grid(row=4, column=0, padx=5, pady=5)

        self.end_button = tk.Button(self.master, text="OK", command=gv.root.destroy, bg ="#cccccc")
        self.end_button.grid(row=4, column=3, padx=5, pady=5, ipadx=2, ipady=2)

    def browse_input1(self):
        filename = filedialog.askopenfilename(filetypes=[("WAV files", "*.wav")])  # otvorenie prehliadaca suborov
        self.input1_entry.delete(0, tk.END)  # vymazanie co je dnu napisane (kvoli vyberu nanovo)
        self.input1_entry.insert(tk.END, filename)  # napisanie cesty dnu do okna
        gv.input1.set(filename)  # zadanie cesty do premennej na pouzitie

    def browse_input2(self):
        filename = filedialog.askopenfilename(filetypes=[("TXT files", "*.txt")])
        self.input2_entry.delete(0, tk.END)
        self.input2_entry.insert(tk.END, filename)
        gv.input2.set(filename)

    def browse_output(self):
        filename = filedialog.asksaveasfilename(filetypes=[("WAV files","*.wav",)])
        self.output_entry.delete(0, tk.END)
        self.output_entry.insert(tk.END, filename)
        gv.output.set(filename)

    def show_dialog(self, content):
        dialog = tk.Toplevel(self.master)  # otvorenie noveho okna
        dialog.title("File Content")  # nadpis okna

        text = tk.Text(dialog)
        text.insert(tk.END, content)  # vypisanie txt suboru do okna
        text.pack(fill="both", expand=True)  # velkost okna podla textu

    def info(self):
        with open('info.txt', 'r') as file:  # otvorenie suboru
            content = file.read()
            self.show_dialog(content)  # spustenie cez tkinter (hned nad tym)

    def help(self):
        with open('help.txt', 'r') as file:
            content = file.read()
            self.show_dialog(content)
