import tkinter as tk


def init():
    global CisloOkna
    CisloOkna = 0
    global root
    root = tk.Tk()  # spustenie GUI

    global input1
    input1 = tk.StringVar()
    global input2
    input2 = tk.StringVar()
    global output
    output = tk.StringVar()
